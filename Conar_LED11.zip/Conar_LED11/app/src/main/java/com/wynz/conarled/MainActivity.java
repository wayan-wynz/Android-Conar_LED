package com.wynz.conarled;
//by I Wayan Sujane DBC 115 027//

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.UUID;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.app.AlertDialog;
import android.content.DialogInterface;

public class MainActivity extends Activity {
  private static final String TAG = "wayan_wynz";
   
  Button btnOn, btnOff, btnDepanOn, btnDepanOff, btnTamuOn, btnTamuOff, btnKamarOn,btnKamarOff, btnDapurOn, btnDapurOff;
  TextView txtArduino;
  Handler h;
  RelativeLayout LayoutBaru;
   
  final int RECIEVE_MESSAGE = 1;		// Status  for Handler
  private BluetoothAdapter btAdapter = null;
  private BluetoothSocket btSocket = null;
  private StringBuilder sb = new StringBuilder();
  private ConnectedThread mConnectedThread;


  // SPP UUID service
  private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
 
  // MAC-address Module Module HC-05
  private static String address = "00:21:13:02:DF:A9";
   
  /** Called when the activity is first created. */
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
 
    setContentView(R.layout.activity_main);

    LayoutBaru = (RelativeLayout) findViewById(R.id.RL);

    btnOn = (Button) findViewById(R.id.btnOn);					// button LED ON
    btnOff = (Button) findViewById(R.id.btnOff);				// button LED OFF

    btnDepanOn = (Button) findViewById(R.id.btnDepanOn);
    btnDepanOff = (Button) findViewById(R.id.btnDepanOff);

    btnTamuOn = (Button) findViewById(R.id.btnTamuOn);
    btnTamuOff = (Button) findViewById(R.id.btnTamuOff);

    btnKamarOn = (Button) findViewById(R.id.btnKamarOn);
    btnKamarOff = (Button) findViewById(R.id.btnKamarOff);

    btnDapurOn = (Button) findViewById(R.id.btnDapurOn);
    btnDapurOff = (Button) findViewById(R.id.btnDapurOff);

    txtArduino = (TextView) findViewById(R.id.txtArduino);		// untuk menampilkan data yang diterima dari arduino
    
    h = new Handler() {
    	public void handleMessage(android.os.Message msg) {
    		switch (msg.what) {
            case RECIEVE_MESSAGE:													// jika menerima data dari arduino
            	byte[] readBuf = (byte[]) msg.obj;
            	String strIncom = new String(readBuf, 0, msg.arg1);			// create string from bytes array
            	sb.append(strIncom);												// append string
            	int endOfLineIndex = sb.indexOf("\r\n");							// determine the end-of-line
            	if (endOfLineIndex > 0) { 											// if end-of-line,
            		String sbprint = sb.substring(0);				// extract string
                    sb.delete(0, sb.length());										// and clear
                	txtArduino.setText("Data dari Arduino: " + sbprint); 	        // update TextView

                    btnOff.setEnabled(true);
                	btnOn.setEnabled(true);

                	btnDepanOn.setEnabled(true);
                	btnDepanOff.setEnabled(true);

                	btnTamuOn.setEnabled(true);
                	btnTamuOff.setEnabled(true);

                	btnKamarOn.setEnabled(true);
                	btnKamarOff.setEnabled(true);

                    btnDapurOn.setEnabled(true);
                    btnDapurOff.setEnabled(true);

                }
            	//Log.d(TAG, "...String:"+ sb.toString() +  "Byte:" + msg.arg1 + "...");
            	//break;
    		}
        };
	};
     
    btAdapter = BluetoothAdapter.getDefaultAdapter(); // Cek bluetooth di hp tersedia atau tidak
    checkBTState();
 
    btnOn.setOnClickListener(new OnClickListener() {
      public void onClick(View v) {
        LayoutBaru.setBackgroundResource(R.drawable.allon);
          btnOn.setEnabled(true);
    	mConnectedThread.write("1");	// kirim "1" via Bluetooth
        Toast.makeText(getBaseContext(), "Mengirim data (1). Semua Lampu Menyala", Toast.LENGTH_SHORT).show();
      }
    });
 
    btnOff.setOnClickListener(new OnClickListener() {
      public void onClick(View v) {
          LayoutBaru.setBackgroundResource(R.drawable.background1);
    	btnOff.setEnabled(true);
    	mConnectedThread.write("a");	// kirim "a" via Bluetooth
        Toast.makeText(getBaseContext(), "Mengirim data (a), Semua Lampu Mati", Toast.LENGTH_LONG).show();
      }
    });

    btnDepanOn.setOnClickListener(new OnClickListener() {
          public void onClick(View v) {
              LayoutBaru.setBackgroundResource(R.drawable.terasdepanon);
        btnDepanOn.setEnabled(true);
        mConnectedThread.write("2");	// kirim "2" via Bluetooth
        Toast.makeText(getBaseContext(), "Mengirim data (2), Teras Depan Menyala", Toast.LENGTH_LONG).show();
          }
      });

    btnDepanOff.setOnClickListener(new OnClickListener() {
          public void onClick(View v) {
              LayoutBaru.setBackgroundResource(R.drawable.background1);
        btnDepanOff.setEnabled(true);
        mConnectedThread.write("b");	// kirim "b" via Bluetooth
        Toast.makeText(getBaseContext(), "Mengirim data (b), Lampu Teras Depan Mati", Toast.LENGTH_SHORT).show();
          }
      });

    btnTamuOn.setOnClickListener(new OnClickListener() {
        public void onClick(View v) {
            LayoutBaru.setBackgroundResource(R.drawable.ruangtamuon);
      	btnTamuOn.setEnabled(true);
      	mConnectedThread.write("3");	// kirim "3" via Bluetooth
            Toast.makeText(getBaseContext(), "Mengirim data (2), Ruang Tamu Menyala", Toast.LENGTH_LONG).show();
        }
      });
    
    btnTamuOff.setOnClickListener(new OnClickListener() {
        public void onClick(View v) {
            LayoutBaru.setBackgroundResource(R.drawable.background1);
      	btnTamuOff.setEnabled(true);
      	mConnectedThread.write("c");	// kirim "c" via Bluetooth
          Toast.makeText(getBaseContext(), "Mengirim data (c), Lampu Ruang Tamu Mati", Toast.LENGTH_SHORT).show();
        }
      });
    
    btnKamarOn.setOnClickListener(new OnClickListener() {
        public void onClick(View v) {
            LayoutBaru.setBackgroundResource(R.drawable.kamaron);
      	btnKamarOn.setEnabled(true);
      	mConnectedThread.write("4");	// kirim "4" via Bluetooth
          Toast.makeText(getBaseContext(), "Mengirim data (4), Lampu Kamar Menyala", Toast.LENGTH_SHORT).show();
        }
      });
    
    btnKamarOff.setOnClickListener(new OnClickListener() {
        public void onClick(View v) {
            LayoutBaru.setBackgroundResource(R.drawable.background1);
      	btnKamarOff.setEnabled(true);
      	mConnectedThread.write("d");	// kirim "d" via Bluetooth
          Toast.makeText(getBaseContext(), "Mengirim data (d), Lampu Kamar Mati", Toast.LENGTH_SHORT).show();
        }
      });

    btnDapurOn.setOnClickListener(new OnClickListener() {
          public void onClick(View v) {
              LayoutBaru.setBackgroundResource(R.drawable.dapuron);
        btnDapurOn.setEnabled(true);
        mConnectedThread.write("5");	// kirim "5" via Bluetooth
              Toast.makeText(getBaseContext(), "Mengirim data (5), Lampu Dapur Menyala", Toast.LENGTH_SHORT).show();
          }
      });

    btnDapurOff.setOnClickListener(new OnClickListener() {
          public void onClick(View v) {
              LayoutBaru.setBackgroundResource(R.drawable.background1);
        btnDapurOff.setEnabled(true);
        mConnectedThread.write("e");	// kirim "e" via Bluetooth
              Toast.makeText(getBaseContext(), "Mengirim data (e), Lampu Dapur Mati", Toast.LENGTH_SHORT).show();
          }
      });

  }


  private BluetoothSocket createBluetoothSocket(BluetoothDevice device) throws IOException {
      if(Build.VERSION.SDK_INT >= 10){
          try {
              final Method  m = device.getClass().getMethod("createInsecureRfcommSocketToServiceRecord", new Class[] { UUID.class });
              return (BluetoothSocket) m.invoke(device, MY_UUID);
          } catch (Exception e) {
              Log.e(TAG, "Could not create Insecure RFComm Connection",e);
              Toast.makeText(getBaseContext(), "Tidak Dapat Tersambung", Toast.LENGTH_LONG).show();
          }
      }
      return  device.createRfcommSocketToServiceRecord(MY_UUID);
  }
   
  @Override
  public void onResume() {
    super.onResume();

    Log.d(TAG, "...onResume - try connect...");
   
    // Set up a pointer to the remote node using it's address.
    BluetoothDevice device = btAdapter.getRemoteDevice(address);


    // Two things are needed to make a connection:
    //   A MAC address, which we got above.
    //   A Service ID or UUID.  In this case we are using the
    //     UUID for SPP.
    
	try {
		btSocket = createBluetoothSocket(device);
	} catch (IOException e) {
		errorExit("ERORRR", "Sedang Menyambungkan() dan socket gagal dibuat: " + e.getMessage() + ".");
	}
    
    try {
      btSocket = device.createRfcommSocketToServiceRecord(MY_UUID);
    } catch (IOException e) {
      errorExit("Fatal Error", "In onResume() and socket create failed: " + e.getMessage() + ".");
    }
   
    // Discovery is resource intensive.  Make sure it isn't going on
    // when you attempt to connect and pass your message.
    btAdapter.cancelDiscovery();

   
    // Establish the connection.  This will block until it connects.
    Log.d(TAG, "...Menyambungkan...");
      txtArduino.setText("Menyambungkan...");
    try {

     // Notifikasi Bluetooth terhubung
      btSocket.connect();
      txtArduino.setText("Bluetooth telah terhubung ke perangkat !");
      Toast.makeText(getBaseContext(), "Bluetooth Terhubung", Toast.LENGTH_LONG).show();
    }

    catch (IOException e) {
      try {
        btSocket.close();
      } catch (IOException e2) {
        errorExit("ERORRR", "Sedang menyambungkan() dan tidak dapat menutup socket selama koneksi gagal" + e2.getMessage() + ".");
      }
    }
     
    // Create a data stream so we can talk to server.
    Log.d(TAG, "...Membuat Socket...");
   
    mConnectedThread = new ConnectedThread(btSocket);
    mConnectedThread.start();
  }
 
  @Override
  public void onPause() {
    super.onPause();
 
    Log.d(TAG, "...Pause()...");
  
    try     {
      btSocket.close();
    } catch (IOException e2) {
      errorExit("ERORRR", "Sedang Pause() dan gagal membuat socket." + e2.getMessage() + ".");
    }
  }

    private void checkBTState() {
        // Check for Bluetooth support and then check to make sure it is turned on
        // Emulator doesn't support Bluetooth and will return null
        if(btAdapter==null) {
            errorExit("ERORRR", "Bluetooth tidak didukung di perangkat ini");
        } else {
            if (btAdapter.isEnabled()) {
                Toast.makeText(getBaseContext(), "Bluetooth Sudah Menyala", Toast.LENGTH_LONG).show();

            } else {
                //Prompt user to turn on Bluetooth
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, 1);

            }
        }
    }




  public void onBackPressed() {
      new AlertDialog.Builder(this).setMessage("Sambungan akan diputuskan. Ingin Keluar Aplikasi ?")
              .setCancelable(false)
              .setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                  public void onClick(DialogInterface dialog, int id) {
                     MainActivity.this.finish();
                  }
              }).setNegativeButton("Tidak", null)
              .show();
  }


  private void errorExit(String title, String message){
    Toast.makeText(getBaseContext(), title + " - " + message, Toast.LENGTH_LONG).show();
    finish();
  }
 
  private class ConnectedThread extends Thread {
	    private final InputStream mmInStream;
	    private final OutputStream mmOutStream;
	 
	    public ConnectedThread(BluetoothSocket socket) {
	        InputStream tmpIn = null;
	        OutputStream tmpOut = null;
	 
	        // Get the input and output streams, using temp objects because
	        // member streams are final
	        try {
	            tmpIn = socket.getInputStream();
	            tmpOut = socket.getOutputStream();
	        } catch (IOException e) { }
	 
	        mmInStream = tmpIn;
	        mmOutStream = tmpOut;
	    }
	 
	    public void run() {
	        byte[] buffer = new byte[1024];  // buffer store for the stream
	        int bytes; // bytes returned from read()

	        // Keep listening to the InputStream until an exception occurs
	        while (true) {
	        	try {
	                // Read from the InputStream
	                bytes = mmInStream.read(buffer);		// Get number of bytes and message in "buffer"
                    h.obtainMessage(RECIEVE_MESSAGE, bytes, -1, buffer).sendToTarget();		// Send to message queue Handler
	            } catch (IOException e) {
	                break;
	            }
	        }
	    }
	 
	    /* Call this from the main activity to send data to the remote device */
	    public void write(String message) {
	    	Log.d(TAG, "Data dikirim:" + message + "...");
	    	byte[] msgBuffer = message.getBytes();
	    	try {
	            mmOutStream.write(msgBuffer);
	        } catch (IOException e) {
	            Log.d(TAG, "Data dikirim Eror: " + e.getMessage() + "...");
	          }
	    }



	}
}